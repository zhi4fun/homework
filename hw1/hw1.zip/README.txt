Code for homework 1
Author: Zhi Chen
Example Usage: 
	Sec2-2:	python hw1.py --sec 22 --env "Ant-v2"
                python hw1.py --sec 22 --env "Humanoid-v2"
	Sec2-3:	python hw1.py --sec 23
	Sec3-2:	python hw1.py --sec 32
